from __future__ import annotations
from dataclasses import dataclass, field
from typing import Callable, List, Optional, Tuple

Vec3 = Tuple[float, float, float]


@dataclass
class Object3D:
    color: str = "#cccccc"
    position: Vec3 = (0, 0, 0)
    rotation: Vec3 = (0, 0, 0)
    spin: float = 0.0  # radians per second around Y axis
    animations: list = field(default_factory=list)
    link: Optional[str] = None  # page to open when clicked, e.g. "/about"
    on_click: Optional[Callable] = None  # def handler(obj) or handler(obj, scene)
    hover_color: Optional[str] = None  # colour while the pointer is over it
    hover_scale: Optional[float] = None  # size multiplier while hovered
    scale: float = 1.0
    physics: Optional[object] = None  # True / "dynamic" falls and collides, "static" is solid ground
    mass: float = 1.0
    bounciness: float = 0.3  # 0 = no bounce, 1 = very bouncy
    kind = "object"

    def animate(self, *anims):
        """Attach animations: Box().animate(Bounce(), ColorShift(to="red"))"""
        self.animations.extend(anims)
        return self

    def clicked(self, fn: Callable):
        """Decorator form of on_click: @box.clicked"""
        self.on_click = fn
        return fn

    def to_dict(self) -> dict:
        return {
            "type": self.kind,
            "color": self.color,
            "position": list(self.position),
            "rotation": list(self.rotation),
            "spin": self.spin,
            "animations": [a.to_dict() for a in self.animations],
            "link": self.link,
            "has_click": self.on_click is not None,
            "hover_color": self.hover_color,
            "hover_scale": self.hover_scale,
            "scale": self.scale,
            "physics": "static" if self.physics == "static" else ("dynamic" if self.physics else None),
            "mass": self.mass,
            "bounciness": self.bounciness,
        }


@dataclass
class Box(Object3D):
    size: Vec3 = (1, 1, 1)
    kind = "box"

    def to_dict(self) -> dict:
        d = super().to_dict()
        d["size"] = list(self.size)
        return d


@dataclass
class Sphere(Object3D):
    radius: float = 0.5
    kind = "sphere"

    def to_dict(self) -> dict:
        d = super().to_dict()
        d["radius"] = self.radius
        return d


class Model(Object3D):
    """A glTF/GLB model. Put the file in your project's assets/ folder."""
    kind = "model"

    def __init__(self, src: str, scale: float = 1.0, position: Vec3 = (0, 0, 0),
                 rotation: Vec3 = (0, 0, 0), spin: float = 0.0, animations=None,
                 link=None, on_click=None, hover_scale=None):
        super().__init__(position=position, rotation=rotation, spin=spin,
                         animations=list(animations or []), link=link,
                         on_click=on_click, hover_scale=hover_scale, scale=scale)
        self.src = src  # e.g. "duck.glb" -> served from /assets/duck.glb

    def to_dict(self) -> dict:
        d = super().to_dict()
        external = self.src.startswith(("http://", "https://", "/"))
        d["src"] = self.src if external else "/assets/" + self.src
        return d


class Text(Object3D):
    """Text floating in the scene, always facing the camera. Any language the device has a font for.

    Use background= to make it look like a button, and link= / on_click= to make it work like one.
    """
    kind = "text"

    def __init__(self, text: str, size: float = 0.5, color: str = "#ffffff",
                 background: Optional[str] = None, position: Vec3 = (0, 0, 0),
                 animations=None, link=None, on_click=None, hover_scale=None,
                 scale: float = 1.0):
        super().__init__(color=color, position=position, animations=list(animations or []),
                         link=link, on_click=on_click, hover_scale=hover_scale, scale=scale)
        self.text = text
        self.size = size  # height of one line in world units
        self.background = background

    def to_dict(self) -> dict:
        d = super().to_dict()
        d["text"] = str(self.text)
        d["size"] = self.size
        d["background"] = self.background
        return d


@dataclass
class Light:
    type: str = "point"
    color: str = "#ffffff"
    intensity: float = 1.0
    position: Vec3 = (5, 5, 5)

    @classmethod
    def point(cls, position: Vec3 = (5, 5, 5), color="#ffffff", intensity=1.0):
        return cls("point", color, intensity, position)

    @classmethod
    def ambient(cls, color="#ffffff", intensity=0.4):
        return cls("ambient", color, intensity)

    def to_dict(self) -> dict:
        return {
            "type": self.type,
            "color": self.color,
            "intensity": self.intensity,
            "position": list(self.position),
        }


@dataclass
class Scene:
    background: str = "#000000"
    camera_position: Vec3 = (0, 1.5, 5)
    orbit_controls: bool = True
    gravity: float = -9.8  # used by objects with physics
    objects: List[Object3D] = field(default_factory=list)
    lights: List[Light] = field(default_factory=list)

    def add(self, item):
        if isinstance(item, Light):
            self.lights.append(item)
        else:
            self.objects.append(item)
        return self

    def object_dicts(self) -> list:
        return [dict(o.to_dict(), id=i) for i, o in enumerate(self.objects)]

    def to_dict(self) -> dict:
        lights = self.lights or [Light.ambient(), Light.point()]
        return {
            "background": self.background,
            "camera": {"position": list(self.camera_position)},
            "orbit": self.orbit_controls,
            "gravity": self.gravity,
            "objects": self.object_dicts(),
            "lights": [l.to_dict() for l in lights],
        }
