"""Per-visitor scene state and click handling (no web framework needed)."""
from __future__ import annotations
import inspect
import traceback
from collections import OrderedDict

MAX_SESSIONS = 500
_sessions: "OrderedDict[tuple, object]" = OrderedDict()


def remember(sid: str, path: str, scene) -> None:
    key = (sid, path)
    _sessions[key] = scene
    _sessions.move_to_end(key)
    while len(_sessions) > MAX_SESSIONS:
        _sessions.popitem(last=False)


def recall(sid: str, path: str):
    return _sessions.get((sid, path))


def _call(handler, obj, scene):
    try:
        wants_scene = len(inspect.signature(handler).parameters) >= 2
    except (TypeError, ValueError):
        wants_scene = False
    return handler(obj, scene) if wants_scene else handler(obj)


def handle_click(scene, index: int) -> dict:
    """Run the click handler of scene.objects[index].

    Returns {"changed": {id: object_dict}}, {"reload": True} or {"error": msg}.
    """
    if scene is None:
        return {"reload": True}
    if not isinstance(index, int) or not 0 <= index < len(scene.objects):
        return {"error": "unknown object"}
    obj = scene.objects[index]
    if obj.on_click is None:
        return {"changed": {}}
    before = scene.object_dicts()
    try:
        _call(obj.on_click, obj, scene)
    except Exception as exc:  # show the user's bug in the terminal, keep serving
        traceback.print_exc()
        return {"error": f"{type(exc).__name__}: {exc}"}
    after = scene.object_dicts()
    if len(after) != len(before):
        return {"reload": True}  # objects were added/removed: simplest is a fresh load
    changed = {i: a for i, (b, a) in enumerate(zip(before, after)) if a != b}
    return {"changed": changed}
