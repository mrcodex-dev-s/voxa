"""`voxa build`: export the site as plain static files (no server needed)."""
from __future__ import annotations
import shutil
from pathlib import Path
from typing import List, Tuple

from .page import render

MARKER = ".voxa-build"


def _normalise_base(base: str) -> str:
    base = (base or "").strip().rstrip("/")
    if base and not base.startswith("/"):
        base = "/" + base
    return base


def _prepare_out(out: Path) -> None:
    if out.exists():
        if (out / MARKER).exists() or not any(out.iterdir()):
            shutil.rmtree(out)
        else:
            raise ValueError(f"'{out}' already exists and was not created by voxa build. "
                             "Choose another --out folder, or delete it yourself.")
    out.mkdir(parents=True)
    (out / MARKER).write_text("created by voxa build\n")


def _fill(pattern: str, values: dict) -> str:
    path = pattern
    for name, value in values.items():
        value = str(value)
        if "/" in value or not value:
            raise ValueError(f"{pattern}: bad value {value!r} for [{name}]")
        path = path.replace(f"[{name}]", value)
    if "[" in path:
        raise ValueError(f"{pattern}: paths() returned {values}, which does not fill every [name]")
    return path


def build_site(app, out, base: str = "", assets_dir: Path = Path("assets")) -> Tuple[List[str], List[str]]:
    """Write one index.html per page into `out`.

    Returns (built_urls, skipped_patterns). A dynamic route is skipped unless its page file
    defines paths(), e.g. def paths(): return [{"slug": "hello"}].
    Links and model URLs are given the `base` prefix by the page's runtime.
    """
    out = Path(out)
    base = _normalise_base(base)
    jobs = [(path, fn, {}) for path, fn in sorted(app.pages.items())]
    skipped: List[str] = []
    for _regex, fn, pattern in app.dynamic:
        paths_fn = app.static_paths.get(pattern)
        if paths_fn is None:
            skipped.append(pattern)
            continue
        for values in paths_fn():
            jobs.append((_fill(pattern, values), fn, values))

    _prepare_out(out)
    built: List[str] = []
    for path, fn, values in jobs:
        scene = fn(**values).to_dict()
        page = render(app.title, {"static": True, "base": base, "scene": scene})
        target = out / "index.html" if path == "/" else out / path.strip("/") / "index.html"
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(page, encoding="utf-8")
        built.append(path)

    if Path(assets_dir).is_dir():
        shutil.copytree(assets_dir, out / "assets")
    (out / ".nojekyll").write_text("")  # GitHub Pages: serve files as-is
    return built, skipped
