from __future__ import annotations
import os
import time
from pathlib import Path

from fastapi import Body, FastAPI, HTTPException
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

from . import events
from .page import render
from .project import load_app

STARTED = str(time.time())


def create_app() -> FastAPI:
    target = os.environ.get("VOXA_APP", "app:app")
    user_app = load_app(target)
    print("Voxa routes:", "  ".join(user_app.routes()) or "(none)")
    api = FastAPI(title=user_app.title)

    assets_dir = Path(os.getcwd()) / "assets"
    assets_dir.mkdir(exist_ok=True)
    api.mount("/assets", StaticFiles(directory=assets_dir), name="assets")

    @api.get("/__voxa/version")
    def version():
        return {"version": STARTED}

    @api.get("/__voxa/scene")
    def scene(path: str = "/", sid: str = ""):
        match = user_app.resolve(path)
        if match is None:
            raise HTTPException(404, f"No page registered for {path}")
        fn, params = match
        built = fn(**params)
        if sid:
            events.remember(sid, path, built)
        return JSONResponse(built.to_dict())

    @api.post("/__voxa/event")
    def event(body: dict = Body(...)):
        scene = events.recall(body.get("sid", ""), body.get("path", "/"))
        if body.get("event") != "click":
            return {"error": "unsupported event"}
        return events.handle_click(scene, body.get("id"))

    @api.get("/{full_path:path}", response_class=HTMLResponse)
    def index(full_path: str):
        path = "/" + full_path
        if user_app.resolve(path) is None:
            raise HTTPException(404, "Page not found")
        return render(user_app.title, {"static": False, "base": ""})

    return api
