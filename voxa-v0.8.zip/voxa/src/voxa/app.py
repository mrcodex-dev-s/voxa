from __future__ import annotations
import re
from typing import Callable, Dict, List, Optional, Tuple
from .scene import Scene


class App:
    def __init__(self, title: str = "Voxa App"):
        self.title = title
        self.pages: Dict[str, Callable[..., Scene]] = {}  # exact paths
        self.dynamic: List[Tuple["re.Pattern", Callable[..., Scene], str]] = []
        # for `voxa build`: dynamic route pattern -> function returning a list of params dicts
        self.static_paths: Dict[str, Callable[[], list]] = {}

    def add_route(self, path: str, fn: Callable[..., Scene]) -> None:
        """Register a page. Segments like [slug] become parameters: /blog/[slug]"""
        if "[" not in path:
            self.pages[self._norm(path)] = fn
            return
        parts = []
        for seg in path.strip("/").split("/"):
            m = re.fullmatch(r"\[(\w+)\]", seg)
            parts.append(f"(?P<{m.group(1)}>[^/]+)" if m else re.escape(seg))
        self.dynamic.append((re.compile("^/" + "/".join(parts) + "$"), fn, path))

    def page(self, path: str = "/"):
        def decorator(fn: Callable[..., Scene]):
            self.add_route(path, fn)
            return fn
        return decorator

    @staticmethod
    def _norm(path: str) -> str:
        return path.rstrip("/") or "/"

    def resolve(self, path: str) -> Optional[Tuple[Callable[..., Scene], dict]]:
        path = self._norm(path)
        if path in self.pages:
            return self.pages[path], {}
        for regex, fn, _ in self.dynamic:
            m = regex.match(path)
            if m:
                return fn, m.groupdict()
        return None

    def routes(self) -> List[str]:
        return sorted(self.pages) + [p for _, _, p in self.dynamic]
