"""Renders the HTML shell that hosts the Three.js runtime."""
from __future__ import annotations
import html
import json
import re
from pathlib import Path

STATIC = Path(__file__).parent / "static"


def render(title: str, config: dict) -> str:
    """config goes to the browser as JSON: {"static": bool, "base": str, "scene": {...}}."""
    page = (STATIC / "index.html").read_text(encoding="utf-8")
    cfg = json.dumps(config, ensure_ascii=False).replace("</", "<\\/")
    values = {"__TITLE__": html.escape(title), "__VOXA_CONFIG__": cfg}
    # one pass, so text inside the scene can never be mistaken for a placeholder
    return re.sub("__TITLE__|__VOXA_CONFIG__", lambda m: values[m.group(0)], page)
