"""Find and load the user's project (app.py and/or pages/)."""
from __future__ import annotations
import importlib
import os
import sys
from pathlib import Path

from .app import App
from .routing import load_pages


def load_user_app(target: str):
    """target looks like 'app:app' (module:variable)."""
    sys.path.insert(0, os.getcwd())
    module_name, _, var = target.partition(":")
    module = importlib.import_module(module_name)
    return getattr(module, var or "app")


def load_app(target: str = "app:app") -> App:
    pages_dir = Path(os.getcwd()) / "pages"
    try:
        app = load_user_app(target)
    except ModuleNotFoundError as exc:
        # No app.py is fine when the project uses a pages/ folder.
        if exc.name == target.partition(":")[0] and pages_dir.is_dir():
            app = App()
        else:
            raise
    load_pages(app, pages_dir)
    return app


load_project = load_app  # alias
