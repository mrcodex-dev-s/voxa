import json
import re

from voxa import App, Scene, Box, Sphere, Text
from voxa.build import build_site, normalize_base


def make_app():
    app = App(title="Test <Site>")

    @app.page("/")
    def home():
        s = Scene()
        s.add(Box(link="/about"))
        s.add(Text("বাংলা </script> test"))
        return s

    @app.page("/about")
    def about():
        return Scene().add(Sphere())

    @app.page("/blog/[slug]")
    def post(slug):
        return Scene(background="#222").add(Text(slug))

    @app.page("/skip/[id]")
    def skipped(id):
        return Scene()

    app.static_paths["/blog/[slug]"] = lambda: [{"slug": "hello"}, {"slug": "a b"}]
    return app


def read_config(path):
    html = path.read_text(encoding="utf-8")
    raw = re.search(r"const CONFIG = (.*?);\n", html, re.S).group(1)
    return html, json.loads(raw.replace("<\\/", "</"))


def test_normalize_base():
    assert normalize_base("") == ""
    assert normalize_base("voxa") == "/voxa"
    assert normalize_base("/voxa/") == "/voxa"


def test_build_pages(tmp_path):
    out = tmp_path / "dist"
    built, skipped = build_site(make_app(), out, base="/voxa")
    assert built == ["/", "/about", "/blog/hello", "/blog/a%20b"]
    assert skipped == ["/skip/[id]"]
    html, cfg = read_config(out / "index.html")
    assert cfg["static"] is True and cfg["base"] == "/voxa"
    assert cfg["scene"]["objects"][0]["link"] == "/about"
    assert "Test &lt;Site&gt;" in html          # title is escaped
    assert "</script> test" not in html          # scene text cannot close the script tag
    assert (out / "about" / "index.html").exists()
    assert (out / "blog" / "hello" / "index.html").exists()
    assert (out / ".nojekyll").exists()


def test_build_copies_assets_and_protects_folders(tmp_path):
    assets = tmp_path / "assets"
    assets.mkdir()
    (assets / "duck.glb").write_bytes(b"glb")
    out = tmp_path / "dist"
    build_site(make_app(), out, assets_dir=assets)
    assert (out / "assets" / "duck.glb").read_bytes() == b"glb"
    build_site(make_app(), out)                  # a Voxa folder can be rebuilt

    other = tmp_path / "mine"
    other.mkdir()
    (other / "important.txt").write_text("keep")
    try:
        build_site(make_app(), other)
        assert False, "should refuse to wipe a folder Voxa did not create"
    except ValueError:
        pass
    assert (other / "important.txt").exists()
