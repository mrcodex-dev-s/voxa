from __future__ import annotations
import importlib
import os
import sys
import time
from pathlib import Path

from fastapi import FastAPI, HTTPException
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

STATIC = Path(__file__).parent / "static"
STARTED = str(time.time())


def load_user_app(target: str):
    """target looks like 'app:app' (module:variable)."""
    sys.path.insert(0, os.getcwd())
    module_name, _, var = target.partition(":")
    module = importlib.import_module(module_name)
    return getattr(module, var or "app")


def create_app() -> FastAPI:
    target = os.environ.get("VOXA_APP", "app:app")
    user_app = load_user_app(target)
    api = FastAPI(title=user_app.title)

    assets_dir = Path(os.getcwd()) / "assets"
    assets_dir.mkdir(exist_ok=True)
    api.mount("/assets", StaticFiles(directory=assets_dir), name="assets")

    @api.get("/__voxa/version")
    def version():
        return {"version": STARTED}

    @api.get("/__voxa/scene")
    def scene(path: str = "/"):
        fn = user_app.pages.get(path)
        if fn is None:
            raise HTTPException(404, f"No page registered for {path}")
        return JSONResponse(fn().to_dict())

    @api.get("/{full_path:path}", response_class=HTMLResponse)
    def index(full_path: str):
        path = "/" + full_path
        if path not in user_app.pages:
            raise HTTPException(404, "Page not found")
        html = (STATIC / "index.html").read_text(encoding="utf-8")
        return html.replace("__TITLE__", user_app.title)

    return api
