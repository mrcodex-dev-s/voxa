from __future__ import annotations
from dataclasses import dataclass
from typing import Tuple

Vec3 = Tuple[float, float, float]


class Animation:
    kind = "animation"

    def to_dict(self) -> dict:
        d = {k: (list(v) if isinstance(v, tuple) else v) for k, v in self.__dict__.items()}
        d["type"] = self.kind
        return d


@dataclass
class Bounce(Animation):
    """Hop up and down. height in world units, speed in hops per ~6 seconds."""
    height: float = 1.0
    speed: float = 3.0
    kind = "bounce"


@dataclass
class Move(Animation):
    """Move from the starting position to `to` and back."""
    to: Vec3 = (2, 0, 0)
    duration: float = 2.0  # seconds one way
    kind = "move"


@dataclass
class ColorShift(Animation):
    """Fade the colour to `to` and back (boxes and spheres)."""
    to: str = "#3b82f6"
    duration: float = 2.0
    kind = "colorshift"


@dataclass
class Pulse(Animation):
    """Grow and shrink. amount=0.2 means +/-20% size."""
    amount: float = 0.2
    speed: float = 3.0
    kind = "pulse"
