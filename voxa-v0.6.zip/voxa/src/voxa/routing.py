"""File-based routing: every .py file in pages/ is a page."""
from __future__ import annotations
import importlib.util
import re
from pathlib import Path


def route_for(rel: Path) -> str:
    parts = list(rel.with_suffix("").parts)
    if parts and parts[-1] == "index":
        parts = parts[:-1]
    return "/" + "/".join(parts)


def load_pages(app, pages_dir: Path) -> list:
    """pages/index.py -> /, pages/about.py -> /about, pages/blog/[slug].py -> /blog/<slug>.
    Each file defines page() (or page(slug) for dynamic routes) and returns a Scene.
    Files and folders starting with _ are ignored."""
    if not pages_dir.is_dir():
        return []
    loaded = []
    for file in sorted(pages_dir.rglob("*.py")):
        rel = file.relative_to(pages_dir)
        if any(part.startswith("_") for part in rel.parts):
            continue
        name = "voxa_page_" + re.sub(r"\W", "_", str(rel.with_suffix("")))
        spec = importlib.util.spec_from_file_location(name, file)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        fn = getattr(module, "page", None)
        if not callable(fn):
            raise RuntimeError(f"pages/{rel.as_posix()} must define a function named page()")
        route = route_for(rel)
        app.add_route(route, fn)
        loaded.append(route)
    return loaded
