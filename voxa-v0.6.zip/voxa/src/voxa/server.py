from __future__ import annotations
import importlib
import os
import sys
import time
from pathlib import Path

from fastapi import Body, FastAPI, HTTPException
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

from . import events
from .app import App
from .routing import load_pages

STATIC = Path(__file__).parent / "static"
STARTED = str(time.time())


def load_user_app(target: str):
    """target looks like 'app:app' (module:variable)."""
    sys.path.insert(0, os.getcwd())
    module_name, _, var = target.partition(":")
    module = importlib.import_module(module_name)
    return getattr(module, var or "app")


def create_app() -> FastAPI:
    target = os.environ.get("VOXA_APP", "app:app")
    pages_dir = Path(os.getcwd()) / "pages"
    try:
        user_app = load_user_app(target)
    except ModuleNotFoundError as exc:
        # No app.py is fine when the project uses a pages/ folder.
        if exc.name == target.partition(":")[0] and pages_dir.is_dir():
            user_app = App()
        else:
            raise
    load_pages(user_app, pages_dir)
    print("Voxa routes:", "  ".join(user_app.routes()) or "(none)")
    api = FastAPI(title=user_app.title)

    assets_dir = Path(os.getcwd()) / "assets"
    assets_dir.mkdir(exist_ok=True)
    api.mount("/assets", StaticFiles(directory=assets_dir), name="assets")

    @api.get("/__voxa/version")
    def version():
        return {"version": STARTED}

    @api.get("/__voxa/scene")
    def scene(path: str = "/", sid: str = ""):
        match = user_app.resolve(path)
        if match is None:
            raise HTTPException(404, f"No page registered for {path}")
        fn, params = match
        built = fn(**params)
        if sid:
            events.remember(sid, path, built)
        return JSONResponse(built.to_dict())

    @api.post("/__voxa/event")
    def event(body: dict = Body(...)):
        scene = events.recall(body.get("sid", ""), body.get("path", "/"))
        if body.get("event") != "click":
            return {"error": "unsupported event"}
        return events.handle_click(scene, body.get("id"))

    @api.get("/{full_path:path}", response_class=HTMLResponse)
    def index(full_path: str):
        path = "/" + full_path
        if user_app.resolve(path) is None:
            raise HTTPException(404, "Page not found")
        html = (STATIC / "index.html").read_text(encoding="utf-8")
        return html.replace("__TITLE__", user_app.title)

    return api
