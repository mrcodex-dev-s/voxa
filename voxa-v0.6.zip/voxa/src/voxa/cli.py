from __future__ import annotations
import os
from pathlib import Path

import typer
import uvicorn

cli = typer.Typer(help="Voxa: build 3D websites with Python.")


TEMPLATE_FILES = {
    "index.py.txt": "pages/index.py",
    "about.py.txt": "pages/about.py",
    "physics.py.txt": "pages/physics.py",
    "blog_slug.py.txt": "pages/blog/[slug].py",
}


@cli.command()
def new(name: str):
    """Create a new Voxa project."""
    root = Path(name)
    if root.exists():
        typer.echo(f"'{name}' already exists.")
        raise typer.Exit(1)
    (root / "assets").mkdir(parents=True)
    tpl_dir = Path(__file__).parent / "templates"
    for src, dest in TEMPLATE_FILES.items():
        target = root / dest
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text((tpl_dir / src).read_text(encoding="utf-8"), encoding="utf-8")
    typer.echo(f"Created {name}/ with pages/ and assets/. Next: cd {name} && voxa dev")


@cli.command()
def dev(
    target: str = typer.Option("app:app", help="module:variable of your App"),
    host: str = "127.0.0.1",
    port: int = 8000,
):
    """Run the dev server with auto reload."""
    os.environ["VOXA_APP"] = target
    typer.echo(f"Voxa dev server: http://{host}:{port}")
    uvicorn.run("voxa.server:create_app", factory=True, host=host, port=port,
                reload=True, reload_dirs=[os.getcwd()])


def main():
    cli()
