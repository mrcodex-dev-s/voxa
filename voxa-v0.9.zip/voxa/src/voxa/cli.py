from __future__ import annotations
import os
import struct
import zlib
from pathlib import Path

import typer
import uvicorn

cli = typer.Typer(help="Voxa: build 3D websites with Python.")


TEMPLATE_FILES = {
    "index.py.txt": "pages/index.py",
    "about.py.txt": "pages/about.py",
    "physics.py.txt": "pages/physics.py",
    "materials.py.txt": "pages/materials.py",
    "blog_slug.py.txt": "pages/blog/[slug].py",
}


def checker_png(size: int = 128, cell: int = 16) -> bytes:
    """A small checkerboard PNG (pure standard library) used by the starter projects."""
    light, dark = (241, 245, 249), (148, 163, 184)
    raw = bytearray()
    for y in range(size):
        raw.append(0)  # PNG filter type: none
        for x in range(size):
            raw.extend(light if (x // cell + y // cell) % 2 == 0 else dark)

    def chunk(tag: bytes, data: bytes) -> bytes:
        body = tag + data
        return struct.pack(">I", len(data)) + body + struct.pack(">I", zlib.crc32(body) & 0xFFFFFFFF)

    header = struct.pack(">IIBBBBB", size, size, 8, 2, 0, 0, 0)
    return (b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", header)
            + chunk(b"IDAT", zlib.compress(bytes(raw))) + chunk(b"IEND", b""))


@cli.command()
def new(name: str):
    """Create a new Voxa project."""
    root = Path(name)
    if root.exists():
        typer.echo(f"'{name}' already exists.")
        raise typer.Exit(1)
    (root / "assets").mkdir(parents=True)
    tpl_dir = Path(__file__).parent / "templates"
    for src, dest in TEMPLATE_FILES.items():
        target = root / dest
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text((tpl_dir / src).read_text(encoding="utf-8"), encoding="utf-8")
    (root / "assets" / "checker.png").write_bytes(checker_png())
    typer.echo(f"Created {name}/ with pages/ and assets/. Next: cd {name} && voxa dev")


@cli.command()
def dev(
    target: str = typer.Option("app:app", help="module:variable of your App"),
    host: str = "127.0.0.1",
    port: int = 8000,
):
    """Run the dev server with auto reload."""
    os.environ["VOXA_APP"] = target
    typer.echo(f"Voxa dev server: http://{host}:{port}")
    uvicorn.run("voxa.server:create_app", factory=True, host=host, port=port,
                reload=True, reload_dirs=[os.getcwd()])


@cli.command()
def build(
    out: str = typer.Option("dist", help="output folder"),
    base: str = typer.Option("", help="site sub-path, e.g. /voxa for GitHub Pages project sites"),
    target: str = typer.Option("app:app", help="module:variable of your App"),
):
    """Export the site as static files (no server needed)."""
    from .build import build_site
    from .project import load_app

    os.environ["VOXA_APP"] = target
    app = load_app(target)
    try:
        built, skipped = build_site(app, out, base=base, assets_dir=Path("assets"))
    except ValueError as exc:
        typer.echo(str(exc))
        raise typer.Exit(1)
    typer.echo(f"Built {len(built)} page(s) into {out}/")
    for url in built:
        typer.echo(f"  {url}")
    for pattern in skipped:
        typer.echo(f"  skipped {pattern}: add a paths() function to the page file to build it")
    typer.echo(f"Preview it with: python -m http.server -d {out}")
    typer.echo("Note: on_click handlers need a running server, so they do nothing in a static build.")


def main():
    cli()
