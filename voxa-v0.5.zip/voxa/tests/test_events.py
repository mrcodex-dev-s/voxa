from voxa import App, Scene, Box, Sphere


def make_app():
    app = App()

    def clicked():
        app.state.count = (app.state.count or 0) + 1

    @app.page("/")
    def home():
        scene = Scene()
        scene.add(Sphere())
        scene.add(Box(on_click=clicked, color="gold" if app.state.count else "red"))
        return scene

    return app


def test_events_serialized():
    d = make_app().build("/").to_dict()
    assert d["objects"][0]["events"] == []
    assert d["objects"][1]["events"] == ["click"]
    assert [o["index"] for o in d["objects"]] == [0, 1]


def test_click_updates_state_and_rebuilds():
    app = make_app()
    scene = app.dispatch("/", 1, "click")
    assert app.state.count == 1
    assert scene.objects[1].color == "gold"


def test_unknown_index_and_event_are_ignored():
    app = make_app()
    app.dispatch("/", 99, "click")
    app.dispatch("/", 1, "hover")
    assert app.state.count is None
