from __future__ import annotations
import traceback
from typing import Callable, Dict
from .scene import Scene


class State(dict):
    """Shared app state with attribute access. Missing keys read as None.

        app.state.count = (app.state.count or 0) + 1
    """

    def __getattr__(self, name):
        return self.get(name)

    def __setattr__(self, name, value):
        self[name] = value


class App:
    def __init__(self, title: str = "Voxa App"):
        self.title = title
        self.pages: Dict[str, Callable[[], Scene]] = {}
        self.state = State()  # shared by every visitor (per-visitor sessions come later)

    def page(self, path: str = "/"):
        def decorator(fn: Callable[[], Scene]):
            self.pages[path] = fn
            return fn
        return decorator

    def build(self, path: str) -> Scene:
        return self.pages[path]()

    def dispatch(self, path: str, index: int, event: str) -> Scene:
        """Run an object's event handler, then rebuild and return the page's scene."""
        scene = self.build(path)
        if 0 <= index < len(scene.objects):
            handler = getattr(scene.objects[index], "on_" + event, None)
            if handler is not None:
                try:
                    handler()
                except Exception:
                    traceback.print_exc()
        return self.build(path)
