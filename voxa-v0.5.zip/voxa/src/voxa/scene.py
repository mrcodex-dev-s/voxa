from __future__ import annotations
from dataclasses import dataclass, field
from typing import Callable, List, Optional, Tuple

Vec3 = Tuple[float, float, float]


@dataclass
class Object3D:
    color: str = "#cccccc"
    position: Vec3 = (0, 0, 0)
    rotation: Vec3 = (0, 0, 0)
    spin: float = 0.0  # radians per second around Y axis
    animations: list = field(default_factory=list)
    link: Optional[str] = None  # page path to open when clicked, e.g. "/about"
    on_click: Optional[Callable] = None   # called (no arguments) when clicked or tapped
    on_hover: Optional[Callable] = None   # called when the pointer enters the object
    on_leave: Optional[Callable] = None   # called when the pointer leaves the object
    kind = "object"

    def animate(self, *anims):
        """Attach animations: Box().animate(Bounce(), ColorShift(to="red"))"""
        self.animations.extend(anims)
        return self

    def to_dict(self) -> dict:
        return {
            "type": self.kind,
            "color": self.color,
            "position": list(self.position),
            "rotation": list(self.rotation),
            "spin": self.spin,
            "animations": [a.to_dict() for a in self.animations],
            "link": self.link,
            "events": [e for e in ("click", "hover", "leave") if getattr(self, "on_" + e, None)],
        }


@dataclass
class Box(Object3D):
    size: Vec3 = (1, 1, 1)
    kind = "box"

    def to_dict(self) -> dict:
        d = super().to_dict()
        d["size"] = list(self.size)
        return d


@dataclass
class Sphere(Object3D):
    radius: float = 0.5
    kind = "sphere"

    def to_dict(self) -> dict:
        d = super().to_dict()
        d["radius"] = self.radius
        return d


class Model(Object3D):
    """A glTF/GLB model. Put the file in your project's assets/ folder."""
    kind = "model"

    def __init__(self, src: str, scale: float = 1.0, position: Vec3 = (0, 0, 0),
                 rotation: Vec3 = (0, 0, 0), spin: float = 0.0, animations=None, link=None,
                 on_click=None, on_hover=None, on_leave=None):
        super().__init__(position=position, rotation=rotation, spin=spin,
                         animations=list(animations or []), link=link,
                         on_click=on_click, on_hover=on_hover, on_leave=on_leave)
        self.src = src  # e.g. "duck.glb" -> served from /assets/duck.glb
        self.scale = scale

    def to_dict(self) -> dict:
        d = super().to_dict()
        external = self.src.startswith(("http://", "https://", "/"))
        d["src"] = self.src if external else "/assets/" + self.src
        d["scale"] = self.scale
        return d


@dataclass
class Light:
    type: str = "point"
    color: str = "#ffffff"
    intensity: float = 1.0
    position: Vec3 = (5, 5, 5)

    @classmethod
    def point(cls, position: Vec3 = (5, 5, 5), color="#ffffff", intensity=1.0):
        return cls("point", color, intensity, position)

    @classmethod
    def ambient(cls, color="#ffffff", intensity=0.4):
        return cls("ambient", color, intensity)

    def to_dict(self) -> dict:
        return {
            "type": self.type,
            "color": self.color,
            "intensity": self.intensity,
            "position": list(self.position),
        }


@dataclass
class Scene:
    background: str = "#000000"
    camera_position: Vec3 = (0, 1.5, 5)
    orbit_controls: bool = True
    objects: List[Object3D] = field(default_factory=list)
    lights: List[Light] = field(default_factory=list)

    def add(self, item):
        if isinstance(item, Light):
            self.lights.append(item)
        else:
            self.objects.append(item)
        return self

    def to_dict(self) -> dict:
        lights = self.lights or [Light.ambient(), Light.point()]
        return {
            "background": self.background,
            "camera": {"position": list(self.camera_position)},
            "orbit": self.orbit_controls,
            "objects": [dict(o.to_dict(), index=i) for i, o in enumerate(self.objects)],
            "lights": [l.to_dict() for l in lights],
        }
