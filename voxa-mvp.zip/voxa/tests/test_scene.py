from voxa import Scene, Box, Sphere, Light


def test_scene_to_dict():
    s = Scene(background="#111")
    s.add(Box(color="red"))
    s.add(Sphere(radius=1))
    s.add(Light.point())
    d = s.to_dict()
    assert d["background"] == "#111"
    assert [o["type"] for o in d["objects"]] == ["box", "sphere"]
    assert len(d["lights"]) == 1
