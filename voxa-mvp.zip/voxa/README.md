# Voxa

Build 3D websites with pure Python.

```python
from voxa import App, Scene, Box, Sphere, Light

app = App()

@app.page("/")
def home():
    scene = Scene(background="#111")
    scene.add(Box(color="tomato", spin=1))
    scene.add(Sphere(radius=0.5, position=(2, 0, 0), color="skyblue"))
    scene.add(Light.point(position=(5, 5, 5)))
    return scene
```

```
voxa new myproject
cd myproject
voxa dev
```
