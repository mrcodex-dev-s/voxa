from __future__ import annotations
import os
from pathlib import Path

import typer
import uvicorn

cli = typer.Typer(help="Voxa: build 3D websites with Python.")


@cli.command()
def new(name: str):
    """Create a new Voxa project."""
    root = Path(name)
    if root.exists():
        typer.echo(f"'{name}' already exists.")
        raise typer.Exit(1)
    root.mkdir(parents=True)
    tpl = Path(__file__).parent / "templates" / "app.py.txt"
    (root / "app.py").write_text(tpl.read_text(encoding="utf-8"), encoding="utf-8")
    typer.echo(f"Created {name}/. Next: cd {name} && voxa dev")


@cli.command()
def dev(
    target: str = typer.Option("app:app", help="module:variable of your App"),
    host: str = "127.0.0.1",
    port: int = 8000,
):
    """Run the dev server with auto reload."""
    os.environ["VOXA_APP"] = target
    typer.echo(f"Voxa dev server: http://{host}:{port}")
    uvicorn.run("voxa.server:create_app", factory=True, host=host, port=port,
                reload=True, reload_dirs=[os.getcwd()])


def main():
    cli()
