from __future__ import annotations
from typing import Callable, Dict
from .scene import Scene


class App:
    def __init__(self, title: str = "Voxa App"):
        self.title = title
        self.pages: Dict[str, Callable[[], Scene]] = {}

    def page(self, path: str = "/"):
        def decorator(fn: Callable[[], Scene]):
            self.pages[path] = fn
            return fn
        return decorator
